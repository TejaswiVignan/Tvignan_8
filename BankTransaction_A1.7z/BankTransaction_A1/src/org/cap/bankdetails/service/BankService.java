package org.cap.bankdetails.service;

import org.cap.bankdetails.Account;
import org.cap.bankdetails.dao.BankDao;

public class BankService {
	Bank bankDaoObj = new Bank(); 
	public void bankAccountCreate(Account bankBeanObjCreateAccountObj) {
		bankDaoObj.getDetails(bankBeanObjCreateAccountObj);
	}

	public void depositSer(Account bankBeanDepObj)
	{ 
			if(bankDaoObj.showDetails().isEmpty()) {
			System.out.println("Please create an account first.");
			} 
			else { 
			if(bankDaoObj.showDetails().containsKey(bankBeanDepObj.getId())) {
			double dep = bankBeanDepObj.getDeposit() + bankDaoObj.showDetails().get(bankBeanDepObj.getId()).getBalance(); // ADDING DEPOSIT AMOUNT TO BANK ACCOUNT 
			bankDaoObj.showDetails().get(bankBeanDepObj.getId()).setBalance(dep);
			System.out.println(" successfully Deposited.");
			System.out.println("Your account balance is: " +bankDaoObj.showDetails().get(bankBeanDepObj.getId()).getBalance()); // PRINTING THE BANK BALANCE 
			}
			else { 
			System.out.println("No such Account Exist.");
			}
			}

}
	public void withdrawSer(Account bankBeanWithdrawObj) 
	{
			if(bankDaoObj.showDetails().isEmpty()) {
			System.out.println("Please create an account first.");
			} 
			else {
			if(bankBeanWithdrawObj.getWithdrawamount() > bankDaoObj.showDetails().get(bankBeanWithdrawObj.getId()).getBalance()) { // CHECKING IF WITHDRAW AMOUNT IS GREATER THAN BALANCE OR NOT
			System.out.println("Can't withdraw money. Account Balance is low."); 
			}
			else { 
			if(bankDaoObj.showDetails().containsKey(bankBeanWithdrawObj.getId())) {
			double dep = bankDaoObj.showDetails().get(bankBeanWithdrawObj.getId()).getBalance() - bankBeanWithdrawObj.getWithdrawamount(); // DECREMENTING WITHDRAW AMOUNT FROM BANK ACCOUNT 
			bankDaoObj.showDetails().get(bankBeanWithdrawObj.getId()).setBalance(dep); 
			System.out.println("Withdraw is successful.");
			System.out.println("Your account balance is: " +bankDaoObj.showDetails().get(bankBeanWithdrawObj.getId()).getBalance()); // PRINTING REMAINING BALANCE 
			} 
			else {
			System.out.println("No such Account Exist."); 
			}
			}
			}
		}

}
