package org.cap.bankdetails;

public class Account {
						
	
	
	private int accountId;
	private String accountName;
	private String Address;
	private int depositAmount;
	public Account(int id, String name, String address2) {
		// TODO Auto-generated constructor stub
	}
	public Account(float withdrawAmount, int id) {
		// TODO Auto-generated constructor stub
	}
	public Account(int id, double depAmount) {
		// TODO Auto-generated constructor stub
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(int depositAmount) {
		this.depositAmount = depositAmount;
	}
	
	public void getDetails() {
		
	}
	public void showDetails() {
		
	}
	public Integer getId() {
		// TODO Auto-generated method stub
		return null;
	}
}
