package org.cap.bankdetails.main;

import java.util.Scanner;

import org.cap.bankdetails.service.Bank;

public class Main {
	public static void main(String args[]) 
	{
	int ch;
	Bank bank = new Bank();
	Scanner sc = new Scanner(System.in);
	while(true){
	System.out.println("\n ------------------\n 1. Create Account \n 2. Deposit \n 3. Withdraw \n 4.Show Account Details\n 5.Pay Loan\n 6. Exit\n------------------------");
	System.out.print("Enter your choice : ");
	ch = sc.nextInt(); 
	switch(ch) {
	case 1:
	bank.createAccount(); 
	break;
	case 2: 
	bank.deposit();
	break;
	case 3:
	bank.withdraw();
	break;
	case 4:
		bank.showAccountDetails();
		break;
	case 5:
		bank.payLoan();
	case 6:
		System.out.println("Thank You !");
	    System.exit(0);
	    break;
	
	}
}
	}
}
