package com.bankapplication.service;

import java.sql.SQLException;

import com.bankapplication.Entity.Account;
import com.bankapplication.Entity.Loan;
import com.bankapplication.exception.BankApplicationException;

public interface BankApplicationService {
	Account getDetails(Account a) throws SQLException;
	boolean showDetails(String accountId) throws SQLException, BankApplicationException;
	 boolean getLoan(Account account, Loan loan) throws BankApplicationException, SQLException;
	 boolean payLoan(String loanId, int loanAmount) throws BankApplicationException, SQLException;
    boolean showLoanDetails(String loanId) throws BankApplicationException, SQLException;
    boolean withDrawAmount(String accountId , double withdrawamount) throws BankApplicationException, SQLException;
	boolean depositAmount(String  accountId, double amount) throws BankApplicationException, SQLException;

}
