package com.bankapplication.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.bankapplication.Dao.AccountDaoImpl;
import com.bankapplication.Dao.LoanDaoImpl;
import com.bankapplication.Dao.TransactionDaoImpl;
import com.bankapplication.Entity.Account;
import com.bankapplication.Entity.Loan;
import com.bankapplication.exception.BankApplicationException;


public class BankApplicationServiceImpl implements BankApplicationService {
AccountDaoImpl accobj= new AccountDaoImpl();
LoanDaoImpl loanobj=new LoanDaoImpl();
TransactionDaoImpl transactionobj=new  TransactionDaoImpl();


@Override
public Account getDetails(Account a) throws SQLException {
	// TODO Auto-generated method stub
	return accobj.getDetails(a);
}

@Override
public boolean showDetails(String accountId) throws SQLException, BankApplicationException {
	// TODO Auto-generated method stub
	return accobj.showDetails(accountId);
}


@Override
public boolean getLoan(Account account, Loan loan) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return loanobj.getLoan(account, loan);
}


@Override
public boolean payLoan(String loanId, int loanAmount) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return loanobj.payLoan(loanId, loanAmount);
}

@Override
public boolean showLoanDetails(String loanId) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return loanobj.showLoanDetails(loanId);
}

@Override
public boolean withDrawAmount(String accountId, double withdrawamount) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return transactionobj.withDrawAmount(accountId, withdrawamount);
}

@Override
public boolean depositAmount(String accountId, double amount) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return transactionobj.depositAmount(accountId, amount);
	
}

public boolean validateamount(double amount) throws BankApplicationException {
	boolean flag= false;
	if(amount<0)
		throw new BankApplicationException("money should be 0");
	else
		flag=true;
	return flag;
}
public boolean Idcheck(String accountId) throws BankApplicationException{
	boolean idFlag=false;
	String nameRegEx = "^[0-9]{7}_FORM$";

	if (!Pattern.matches(nameRegEx, accountId)) {
		throw new BankApplicationException("enter the id in respective format 1234567_FORM");
	} else {
		idFlag = true;
	}
	
	return idFlag;
}
public boolean validateName(String accountName) throws BankApplicationException {
	boolean flag=false;
	String regex = "[A-Z]{1}[a-zA-Z]{2,}";
	Pattern pattren = Pattern.compile(regex);
	Matcher matches = pattren.matcher(accountName);
	if (!matches.matches()) {
		throw new BankApplicationException("CAPITAL LETTERS ONLY");	
	}
	else
		flag=true;
	return flag;
}
public boolean validateLoan(String loanType) throws BankApplicationException {
	if (loanType.equalsIgnoreCase("house") || loanType.equalsIgnoreCase("gold")
			|| loanType.equalsIgnoreCase("study"))
		return true;
	else {
		throw new BankApplicationException("Avaliable Loans for house,gold and study");

	}
}

public boolean serachLoan(String loanId1) throws BankApplicationException, SQLException {
	// TODO Auto-generated method stub
	return loanobj.searchLoan(loanId1);
}

}
