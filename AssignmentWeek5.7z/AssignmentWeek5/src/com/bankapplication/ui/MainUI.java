package com.bankapplication.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.bankapplication.Entity.Account;
import com.bankapplication.Entity.Loan;
import com.bankapplication.exception.BankApplicationException;
import com.bankapplication.service.BankApplicationServiceImpl;



public class MainUI {
	public static void main(String[] args) throws SQLException, BankApplicationException {
	
BankApplicationServiceImpl serviceobj=new BankApplicationServiceImpl();
Loan loan=new Loan();
Scanner scanner = new Scanner(System.in);
int option;

while(true) {
	System.out.println("1.Account\n2.Loan\n3.Transaction\n4.exit");
	System.out.println("Enter your option");
	option=scanner.nextInt();
	switch(option) {
	case 1:
		int option1;
		System.out.println("1. New account\n 2. Get account details\n");
		System.out.println("Enter your option");
		option1=scanner.nextInt();
		switch(option1) {
		case 1:
			boolean id=false;
			boolean nameCheck=false;
			String accountId="";
			String accountName="";
			String address="";
			int deposit=0;
			do {
            	System.out.println("Enter AccountID:");
                 accountId=scanner.next();
                try {
                	serviceobj.Idcheck(accountId);
                	id=true;
                }catch(BankApplicationException e) {
                	id=false;
                	System.err.println(e.getMessage());
                }}while(!id);

            do {
            System.out.println("Enter Acount Name:");
             accountName=scanner.next();
            try {
            	serviceobj.validateName(accountName);
            	nameCheck=true;
            }catch(BankApplicationException e) {
            	nameCheck=false;
            	System.out.println(e.getMessage());
            }
            }while (!nameCheck);
            System.out.println("Enter Address");
            address=scanner.next(); 
            System.out.println("Enter deposit amount");
            deposit=scanner.nextInt();
            Account account=new Account(accountId,accountName,address,deposit);
            serviceobj.getDetails(account);
			break;
		case 2:System.out.println("Enter AccountId:");
		String accId=scanner.next();
		serviceobj.showDetails(accId);
			break;
		}	
		break;
	case 2:
		boolean choiceFlag2 = false;
		int choice4 = 0;
		 String accountId2=null;
	     Account account2=new Account(accountId2);
		do {
			try {
				System.out.println("1.Take Loan 2.View loandetails");
				choice4 = scanner.nextInt();
				choiceFlag2 = true;

				switch (choice4) {
				case 1:
					boolean loanflag = false;
					String loanType;
					do {
						System.out.println("Enter Loan type: ");
						loanType = scanner.next();
						loan.setLoanType(loanType);
						
						try {
							loanflag = serviceobj.validateLoan(loanType);
						} catch (BankApplicationException e) {
							System.out.println(e.getMessage());
						}
					} while (!loanflag);
					System.out.println("enter Loan amount: ");
					int amount = scanner.nextInt();
					loan.setLoanAmount(amount);
					System.out.println("enter Accountno:");
					String accountNumber = scanner.next();
					String loanId1 =accountNumber;
					loan.setLoanId(loanId1);
					account2.setAccountId(accountNumber);
					serviceobj.getLoan(account2, loan);
					System.out.println(	"loan added with loanId: " + loan.getLoanId());
					break;
				
				case 2:
					try {
					System.out.println("Enter loan Id");
					loanId1 = scanner.next();
					serviceobj.serachLoan(loanId1);
					serviceobj.showLoanDetails(loanId1);
				} catch (BankApplicationException e) {
					System.out.println(e.getMessage());
				}
			
				break;
				}
			}
			catch (InputMismatchException e) {
				scanner.nextLine();
				choiceFlag2 = false;

				System.out.println("Enter digit only");
			} }while (!(choiceFlag2));
			choiceFlag2 = true;
			break;
	case 3:
		
		boolean choiceFlag3 = false;
		boolean transFlag3 = false;
          String accountId1=null;
          System.out.println("enter accountId:");
          accountId1=scanner.next();
		do {
			try {
				System.out.println("1. Deposit Amount 2. Withdraw 3.payLoan ");
				option = scanner.nextInt();
				scanner.nextLine();
				choiceFlag3 = true;
				switch (option) {
				case 1:
  
					do {
						System.out.println("Enter amount to be deposited: ");
						double depositamount = scanner.nextDouble();
						try {
							transFlag3 = serviceobj.validateamount(depositamount);
							serviceobj.depositAmount(accountId1, depositamount);
							System.out.println(depositamount+"   Amount deposited");
						} catch (BankApplicationException e) {
							System.out.println(e.getMessage());
						}

					} while (!transFlag3);
					transFlag3 = false;
					break;
				case 2:
					do {
						System.out.println("Enter amount to be withdraw: ");
						double withdrawamount = scanner.nextDouble();
						try {
							transFlag3 = serviceobj.validateamount(withdrawamount);
							serviceobj.withDrawAmount(accountId1, withdrawamount);
							System.out.println(withdrawamount+"Amount withdrawn");
						} catch (BankApplicationException e) {
							System.out.println(e.getMessage());
						}
					} while (!transFlag3);
					transFlag3 = false;
					break;
				case 3:

				try {
					System.out.println("Enter loan Id");
					String loanId1 = scanner.next();
					serviceobj.serachLoan(loanId1);
					System.out.println("Enter amount: ");
					int loanAmount1 = scanner.nextInt();
					serviceobj.payLoan(loanId1, loanAmount1);
				} catch (BankApplicationException e) {
					System.out.println(e.getMessage());
				}
				break;
				
				default:
					choiceFlag3 = false;
					System.out.println("Please enter valid choice");
					break;

				}
			} catch (InputMismatchException e) {
				scanner.nextLine();
				choiceFlag3 = false;
				System.out.println("Enter digit only");
			}
		} while (!(choiceFlag3));break;
	case 4:System.out.println("Gracias !");
	System.exit(0);
	break;
	}
	}
}
}

