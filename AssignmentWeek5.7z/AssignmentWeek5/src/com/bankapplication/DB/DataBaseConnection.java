package com.bankapplication.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {
	private static Connection connection;
	public static Connection getConnection() throws SQLException {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/john", "root", "1718");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return connection;
	}
		
	}


