package com.bankapplication.exception;

public class BankApplicationException extends Exception {
	
	public  BankApplicationException(String message) {
		super(message);
	}
	


}
