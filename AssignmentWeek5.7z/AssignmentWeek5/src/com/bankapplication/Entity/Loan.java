package com.bankapplication.Entity;

public class Loan extends Account {
private String loanId;
private String loanType;
private int loanAmount;

public String getLoanId() {
	return loanId;
}
public void setLoanId(String loanId) {
	this.loanId = loanId;
}
public String getLoanType() {
	return loanType;
}
public void setLoanType(String loanType) {
	this.loanType = loanType;
}


public int getLoanAmount() {
	return loanAmount;
}
public void setLoanAmount(int loanAmount) {
	this.loanAmount = loanAmount;
}
public Loan(String accountId, String accountName, String address, int depositAmount, String loanId, String loanType,
		int loanAmount) {
	super(accountId, accountName, address, depositAmount);
	this.loanId = loanId;
	this.loanType = loanType;
	this.loanAmount = loanAmount;
}

public Loan() {
	// TODO Auto-generated constructor stub
}
public Loan(String loanId2, String loanType2, int amount) {
	// TODO Auto-generated constructor stub
}
public String showLoanDetails() {
	return "Loan [loanId=" + loanId + ", loanType=" + loanType + ", loanAmount=" + loanAmount + "]";
}

}
