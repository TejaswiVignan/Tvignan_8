package com.bankapplication.Entity;

public class Account {
private String accountId;
private String accountName;
private String address;
private int depositAmount;


public String getAccountId() {
	return accountId;
}
public void setAccountId(String accountId) {
	this.accountId = accountId;
}
public String getAccountName() {
	return accountName;
}
public void setAccountName(String accountName) {
	this.accountName = accountName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getDepositAmount() {
	return depositAmount;
}
public void setDepositAmount(int depositAmount) {
	this.depositAmount = depositAmount;
}

public Account(String accountId2) {
	// TODO Auto-generated constructor stub
}

public Account() {
	// TODO Auto-generated constructor stub
}
public Account(String accountId2, String accountName2, String address2, int deposit) {
	// TODO Auto-generated constructor stub
}




}
