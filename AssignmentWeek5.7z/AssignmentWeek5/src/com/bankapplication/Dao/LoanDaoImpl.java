package com.bankapplication.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bankapplication.DB.DataBaseConnection;
import com.bankapplication.Entity.Account;
import com.bankapplication.Entity.Loan;
import com.bankapplication.exception.BankApplicationException;



public class LoanDaoImpl implements LoanDao{
	Connection connection=null;
	PreparedStatement prepStmt=null ;
	ResultSet rs=null;
	@Override
	public boolean getLoan(Account account, Loan loan) throws BankApplicationException, SQLException {
	
	 connection = DataBaseConnection.getConnection();
		 prepStmt = connection.prepareStatement("insert into loan values(?,?,?,?)");
		 prepStmt.setString(1, loan.getLoanId());
		 prepStmt.setString(2, account.getAccountId());
		 prepStmt.setString(3, loan.getLoanType());
		 prepStmt.setInt(4, loan.getLoanAmount());
			
		return true;
	}

	@Override
	public boolean payLoan(String loanId,int loanAmount) throws BankApplicationException, SQLException {
		int transactionId = (int) (Math.random() * 10000000);	
	connection = DataBaseConnection.getConnection();
			prepStmt=connection.prepareStatement("select loanId,accountId,loanType,loanAmount from loan where loanId=?");
			prepStmt.setString(1, loanId);
			rs=prepStmt.executeQuery();
			rs.next();
			int intialamnt=rs.getInt(4);
			if(intialamnt>loanAmount) {
				intialamnt=intialamnt-loanAmount;
				System.out.println("Balancing Amount To Be pay:"+intialamnt);
			}
			else
				throw new BankApplicationException("insufficient amount");
				prepStmt=connection.prepareStatement("update loan set loanAmount=? where loanId=?");
				prepStmt.setDouble(1, intialamnt);
				prepStmt.setString(2, loanId);
				prepStmt = connection.prepareStatement("insert into transaction values(?,?,?,?)");
				prepStmt.setInt(1, transactionId);
				prepStmt.setString(2, loanId);
				prepStmt.setString(3, "loan deposit ");
				prepStmt.setDouble(4, loanAmount);
				prepStmt.executeUpdate();
		
		return true;
	}
	@Override
	public boolean showLoanDetails(String loanId) throws BankApplicationException, SQLException {
		
		boolean flag=false;
		 connection = DataBaseConnection.getConnection();
			prepStmt=connection.prepareStatement("select loanId,accountId,loanType,loanAmount from loan where loanId=?");
			prepStmt.setString(1, loanId);
			rs=prepStmt.executeQuery();
			while(rs.next()) {
				Loan loan= new Loan();
				loan.setLoanId(rs.getString(1));
				loan.setLoanType(rs.getString(3));
				loan.setLoanAmount(rs.getInt(4));
				System.out.println("LoanId:"+loan.getLoanId()+"\nLoan Type:"+loan.getLoanType()+"\nLoan Amount:"+loan.getLoanAmount());
			}
				
				
		return flag;
	}
	public boolean searchLoan(String loanId) throws BankApplicationException, SQLException {

		boolean flag=false;
	connection = DataBaseConnection.getConnection();
			prepStmt=connection.prepareStatement("select loanType from loan where loanId=?");
			prepStmt.setString(1, loanId);
			rs=prepStmt.executeQuery();
			if(rs.next()) {
				flag=true;
				
			}
			else
				throw new BankApplicationException("loan type not there");
		
		return flag;
	}

}

