package com.bankapplication.Dao;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bankapplication.DB.DataBaseConnection;
import com.bankapplication.Entity.Account;
import com.bankapplication.exception.BankApplicationException;

public class AccountDaoImpl implements AccountDao {
    Connection connection=null;
	PreparedStatement prepStmt=null ;
	ResultSet rs=null;

	@Override
	public Account getDetails(Account a) throws SQLException {
		// TODO Auto-generated method stub
	
			connection = DataBaseConnection.getConnection();
		
		try {
			prepStmt = connection.prepareStatement("insert into account values(?,?,?,?)");
			prepStmt.setString(1,a.getAccountId());
			prepStmt.setString(2, a.getAccountName());
			prepStmt.setString(3, a.getAddress());
			prepStmt.setInt(4,a.getDepositAmount());
			int i = prepStmt.executeUpdate();
			if(i>0)
				System.out.println("Customer inserted Successfully!!!!");
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean showDetails(String accountId) throws SQLException, BankApplicationException {
		// TODO Auto-generated method stub
		boolean flag=false;
		 connection = DataBaseConnection.getConnection() ;
			prepStmt=connection.prepareStatement("select accountId,accountName,address,depositAmount from account where accountId=?");
			prepStmt.setString(1,accountId);
	    	rs=prepStmt.executeQuery();
			while(rs.next()) {
				Account account1= new Account();
				account1.setAccountId(rs.getString(1));
				account1.setAccountName(rs.getString(2));
				account1.setAddress(rs.getString(3));
				account1.setDepositAmount(rs.getInt(4));
				System.out.println("accountId:"+accountId+"\nname:"+account1.getAccountName()+"\naddress:"+account1.getAddress()+"\ndeposit:"+account1.getDepositAmount());
			}
				
		
		return flag;
	}

	

}
