package com.bankapplication.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bankapplication.DB.DataBaseConnection;
import com.bankapplication.exception.BankApplicationException;

public class TransactionDaoImpl implements TransactionDao{
	Connection connection=null;
	PreparedStatement prepStmt=null ;
	ResultSet rs=null;
	@Override
	public boolean depositAmount(String  accountId, double amount) throws BankApplicationException, SQLException {
		int transactionId = (int) (Math.random() * 10000000);
		connection = DataBaseConnection.getConnection(); 
			prepStmt=connection.prepareStatement("select accountId,accountName,address,depositAmount from account where accountId=?");
			prepStmt.setString(1, accountId);
			rs=prepStmt.executeQuery();
			rs.next();
			double intialamnt=rs.getDouble(4);
			double amnt=amount+intialamnt;
			prepStmt=connection.prepareStatement("update account set depositAmount=? where accountId=?");
			prepStmt.setDouble(1, amnt);
			prepStmt.setString(2, accountId);
			prepStmt.executeUpdate();
			prepStmt = connection.prepareStatement("insert into transaction values(?,?,?,?)");
			prepStmt.setInt(1, transactionId);
			prepStmt.setString(2, accountId);
			prepStmt.setString(3, "deposit");
			prepStmt.setDouble(4, amount);
			prepStmt.executeUpdate();
	
		return true;
	
}

	@Override
	public boolean withDrawAmount(String accountId , double withdrawamount) throws BankApplicationException, SQLException {
		
		int transactionId = (int) (Math.random() * 10000000);
		connection = DataBaseConnection.getConnection() ;
			prepStmt=connection.prepareStatement("select accountId,accountName,address,depositAmount from account where accountId=?");
			prepStmt.setString(1, accountId);
			rs=prepStmt.executeQuery();
			rs.next();
			double intialamnt=rs.getInt(4);
			if(intialamnt>withdrawamount)
				intialamnt=intialamnt-withdrawamount;
			else
				throw new BankApplicationException("insufficient amount");
			prepStmt=connection.prepareStatement("update account set depositAmount=? where accountId=?");
			prepStmt.setDouble(1, intialamnt);
			prepStmt.setString(2, accountId);
			prepStmt.executeUpdate();
			prepStmt = connection.prepareStatement("insert into transaction values(?,?,?,?)");
			prepStmt.setInt(1, transactionId);
			prepStmt.setString(2, accountId);
			prepStmt.setString(3, "withdraw ");
			prepStmt.setDouble(4, withdrawamount);
			prepStmt.executeUpdate();
		
		return true;
	}
	
}
