package com.bankapplication.Dao;

import java.sql.SQLException;

import com.bankapplication.Entity.Account;
import com.bankapplication.exception.BankApplicationException;

public interface AccountDao{
Account getDetails(Account a) throws SQLException;
boolean showDetails(String accountId) throws SQLException, BankApplicationException;


}
