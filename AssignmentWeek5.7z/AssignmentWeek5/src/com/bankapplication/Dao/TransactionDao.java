package com.bankapplication.Dao;

import java.sql.SQLException;
import com.bankapplication.exception.BankApplicationException;

public interface TransactionDao {
	boolean withDrawAmount(String accountId , double withdrawamount) throws BankApplicationException, SQLException;
	boolean depositAmount(String  accountId, double amount) throws BankApplicationException, SQLException;

}
