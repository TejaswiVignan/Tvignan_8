package com.bankapplication.Dao;

import java.sql.SQLException;

import com.bankapplication.Entity.Account;
import com.bankapplication.Entity.Loan;
import com.bankapplication.exception.BankApplicationException;


public interface LoanDao {
	 boolean getLoan(Account account, Loan loan) throws BankApplicationException, SQLException;
	 boolean payLoan(String loanId, int loanAmount) throws BankApplicationException, SQLException;
     boolean showLoanDetails(String loanId) throws BankApplicationException, SQLException;
}
