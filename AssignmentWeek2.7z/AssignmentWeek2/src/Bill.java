import java.util.*;
import java.util.concurrent.TimeUnit;
public class Bill {

	User user;  
	/*{
	 * "userType":"Employee",
	 * "joinedOn":1595413629
	 * } */
	Boolean isGroceries = false;
	Double bill; //989.00
	
	public static void main (String[] args) {
		String userType = null;
		Boolean isGroceries = false;
		Long createdOn = 0L;
		Double bill = 0D;
		Scanner scan = new Scanner(System.in);
		try {
		System.out.println("enter the userType can be Employee/Affiliate/Customer");
		userType = scan.next();
		System.out.println("enter if groceries are present in the list true/false");
		isGroceries = scan.nextBoolean();
		System.out.println("enter the bill in decimals");
		String billAmount = scan.next();
		bill = Double.parseDouble(billAmount);
		System.out.println("enter the user created time in epoch ms");
		createdOn = scan.nextLong();
		} catch (Exception e) {
			System.out.println( e.getMessage());
		}
		User user = User.createOrGetUser(userType, createdOn);
		
		Double finalBill = 0.0; 
		int generalDiscount = 0;
		int userDiscount =0;
		switch(user.getUserType().getValue()) {
		case "Employee":
			generalDiscount = checkAndReturnIfElligbleForGeneralDiscount(bill);
			userDiscount = user.getUserType().getDiscount();
			finalBill = calculateFinalBill(userDiscount, generalDiscount, bill, isGroceries);
			break;
		case "Affiliate":
			generalDiscount = checkAndReturnIfElligbleForGeneralDiscount(bill);
			userDiscount = user.getUserType().getDiscount();
			finalBill = calculateFinalBill(userDiscount, generalDiscount, bill, isGroceries);
			break;
		case "Customer":
			generalDiscount = checkAndReturnIfElligbleForGeneralDiscount(bill);
			Long customerCreatedDate = user.getJoinedOn();
			Long currentTimeStamp = new Date().getTime();
			
			long diffInMillisec = Math.abs(currentTimeStamp - customerCreatedDate);
	        Long dayDiff = TimeUnit.DAYS.convert(diffInMillisec, TimeUnit.MILLISECONDS);
	        if(dayDiff > 730) {
	        	userDiscount = user.getUserType().getDiscount();
	        }else {
	        	userDiscount = 0;
	        }
			finalBill = calculateFinalBill(userDiscount, generalDiscount, bill, isGroceries);
			break;
			
		default:
			finalBill = 0.0;
			break;
			
		}
		
		System.out.println("final bill is " + finalBill);
		
		
	}
	
	public static int checkAndReturnIfElligbleForGeneralDiscount(Double bill) {
		return (int)(bill/100)*5;
	}
	
	public static Double calculateFinalBill(Integer userDiscount, Integer generalDiscount, Double bill, Boolean isGroceries) {
		Double finalBill = bill-generalDiscount;
		if(userDiscount != 0 && !isGroceries) {
		finalBill = finalBill - (Double)((userDiscount)/100D)*(finalBill);
		}
		return finalBill;
	}
	
}
