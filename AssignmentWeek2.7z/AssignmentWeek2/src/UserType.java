public enum UserType {

	
    EMPLOYEE("Employee",30),
    AFFILIATE("Affiliate",10),
    CUSTOMER("Customer",5);
    
    
    private final String value;
    private final Integer discount;
    
    public String getValue() {
    	return value;
    }
    
    public Integer getDiscount() {
    	return discount;
    }
  
    private UserType(String value, Integer discount) {
        this.value = value;
        this.discount = discount;
    }
    
    public static UserType getUserType(String type) {
        UserType userType = null;
        for(UserType currUserType : UserType.values()){
            if(currUserType.name().equalsIgnoreCase(type.trim())) {
                userType = currUserType;
                break;
            }
        }

        
        return userType;
    }

}
