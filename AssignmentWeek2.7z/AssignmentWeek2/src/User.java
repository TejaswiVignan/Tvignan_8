public class User {
	
	UserType userType;
	Long joinedOn;
	
	
	 public UserType getUserType() {
	        return userType;
	    }

	    public void setUserType(UserType userType) {
	        this.userType = userType;
	    }

	    public Long getJoinedOn() {
	        return joinedOn;
	    }

	    public void setJoinedOn(Long joinedOn) {
	        this.joinedOn = joinedOn;
	    }
	

	    public static User createOrGetUser(String userTypeName, Long joinedOn) {
	    	User user = new User();
	    	user.setJoinedOn(joinedOn);
	    	UserType userType = UserType.getUserType(userTypeName);
	    	user.setUserType(userType);
	    	return user;
	    }
	    
}
