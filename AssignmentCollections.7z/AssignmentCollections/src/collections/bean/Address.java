package collections.bean;

import collections.bean.Address;

public class Address {
	private int addressId;
	private String Addressline1;
	private String City;
	private String state;
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddressline1() {
		return Addressline1;
	}
	public void setAddressline1(String addressline1) {
		Addressline1 = addressline1;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Address(int addressId, String addressline1, String city, String state) {
		super();
		this.addressId = addressId;
		Addressline1 = addressline1;
		City = city;
		this.state = state;
	}
	public Address(String state2) {
		// TODO Auto-generated constructor stub
		this.state=state2;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", Addressline1=" + Addressline1 + ", City=" + City + ", state=" + state
				+ "]";
	}
	public int compareTo(Address address) {
		// TODO Auto-generated method stub
		
		if(this.addressId<address.getAddressId())
			return -1;
		if(this.addressId>address.getAddressId())
			return -1;
		else 
			return 0;
	}

}
