package collections.bean;

import collections.bean.Address;
import collections.bean.Department;
import collections.bean.Employee;

public class Employee {
	private String employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	private String dateOfjoining;
	private Department department;
	private Address address;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDateOfjoining() {
		return dateOfjoining;
	}
	public void setDateOfjoining(String dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Employee(String employeeId, String firstName, String lastName, double salary, String dateOfjoining,
			Department department, Address address) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dateOfjoining = dateOfjoining;
		this.department = department;
		this.address = address;
	}
	public int compareTo(Employee employee) {
		// TODO Auto-generated method stub
		if((this.getEmployeeId().compareTo(employee.getEmployeeId()))<0)
		return -1;
		if((this.getEmployeeId().compareTo(employee.getEmployeeId()))>0)
			return 1;
		else
			return 0;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", dateOfjoining=" + dateOfjoining + ", department=" + department
				+ ", address=" + address + "]";
	}
	

}
