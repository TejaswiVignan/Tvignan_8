package collections.dao;

import java.util.List;

import collections.bean.Employee;

public interface EmployeeDao {
	
 public boolean insertEmployee(Employee emp);
 public List<Employee> getList();

}
