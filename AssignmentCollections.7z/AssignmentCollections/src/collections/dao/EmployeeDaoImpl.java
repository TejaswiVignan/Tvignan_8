package collections.dao;

import java.util.ArrayList;
import java.util.List;

import collections.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	 List<Employee> list = new ArrayList<Employee>();

		@Override
		public boolean insertEmployee(Employee employee) {
			// TODO Auto-generated method stub
		
			  list.add(employee);
				 System.out.println("added successfully");
				 return true;
		
			 }
		public List<Employee> getList() {
			// TODO Auto-generated method stub
			return list;
		}
}
