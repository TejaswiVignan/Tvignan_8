package collections.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import collections.bean.Address;
import collections.bean.Department;
import collections.bean.Employee;
import collections.exception.EmployeeException;
import collections.service.EmployeeServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		EmployeeServiceImpl serviceobj=new EmployeeServiceImpl();
		Scanner scanner=new Scanner(System.in);

		int choice;
		while(true) {
			System.out.println("1.Save Employee\n2.Sort Employee\n3.Exit");
			System.out.println("Enter your choice:");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				boolean NameFlag=false;
				boolean SalaryFlag=false;
				boolean IdFlag=false;
				String employeeId="";
				String firstName="";
            	String lastName="";
            	double salary=0.00;
            	do {
            	System.out.println("enter employee Id:");
                 employeeId=scanner.next();
                try {
                	serviceobj.Idcheck(employeeId);
                	IdFlag=true;
                }catch(EmployeeException e) {
                	IdFlag=false;
                	System.err.println(e.getMessage());
                }}while(!IdFlag);
			
                do {
                System.out.println("enter firstname:");
                 firstName=scanner.next();
                try {
                	serviceobj.validateName(firstName);
                	NameFlag=true;
                }catch(EmployeeException e) {
                	NameFlag=false;
                	System.err.println(e.getMessage());
                }
                }while (!NameFlag);
                do {
                System.out.println("enter last name:");
                 lastName=scanner.next();
                try {
                	serviceobj.validateName(lastName);
                	NameFlag=true;
                }catch(EmployeeException e){
                	NameFlag=false;
                	System.err.println(e.getMessage());
                }
                }while (!NameFlag);
                	do {
                System.out.println("enter salary");
                 salary=scanner.nextDouble();
                try {
                	serviceobj.salaryCheck(salary);
                	SalaryFlag=true;
                }catch(EmployeeException e) {
                	SalaryFlag=false;
                	System.err.println(e.getMessage());
                }
                	}while (!SalaryFlag);
                System.out.println("enter date of joining:");
                String date=scanner.next();
                System.out.println("department details");
                System.out.println("enter departmentId:");
                int departId=scanner.nextInt();
               System.out.println("enter department name:");
               String departName=scanner.next();
               System.out.println("enter location:");
               String location=scanner.next();
               System.out.println("address");
               System.out.println("enter addressId:");
               int addressId=scanner.nextInt();
               System.out.println("enter Adress line1");
               String address=scanner.next();
               System.out.println("enter city");
               String city=scanner.next();
               System.out.println("enter state");
               String state=scanner.next();
               Address addresses=new Address(addressId, address, city, state);
                Department department=new Department(departId, departName, location);
                Employee employee=new Employee(employeeId, firstName, lastName, salary, date, department, addresses);
            	serviceobj.insertEmployee(employee);
            	System.out.println(employee);
				break;
			case 2:
				int choice2;
				System.out.println("1.sort by employeeId \n 2.sort by firstname \n 3.sort by lastname \n 4.sort by salary \n 5.sort by address \n 6.sort by department");
                System.out.println("enter your choice:");	
                choice2=scanner.nextInt();
                switch(choice2) {
                case 1:
                		List<Employee> employees1 = new ArrayList<Employee>();
					employees1 = serviceobj.ById();
					for (Employee employee1 : employees1) {
						System.out.println(employee1);
					}
                		break;
                case 2:
       List<Employee> employees2=new ArrayList<Employee>();
       employees2 =serviceobj.ByFirstName();
       for(Employee employee2: employees2) {
    	   System.out.println(employee2);
       }
                	break;
                case 3:
                	 List<Employee> employees3=new ArrayList<Employee>();
                     employees3 =serviceobj.ByLastName();
                     for(Employee employee3: employees3) {
                  	   System.out.println(employee3);
                     }
                	break;
                case 4:
                	 List<Employee> employees4=new ArrayList<Employee>();
                     employees4=serviceobj.BySalary();
                     for(Employee employee4: employees4) {
                  	   System.out.println(employee4);
                     }
                	break;
                case 5:
                	 List<Employee> employees5=new ArrayList<Employee>();
                     employees5=serviceobj.ByAddress();
                     for(Employee employee5: employees5) {
                  	   System.out.println(employee5);
                     }
                	break;
                case 6:
                	 List<Employee> employees6=new ArrayList<Employee>();
                     employees6=serviceobj.ByDepartment();
                     for(Employee employee6: employees6) {
                  	   System.out.println(employee6);
                     }
                	break;
                
			
                }break;
			case 3:
				System.out.println("thank you");
				System.exit(0);
				break;
			}
			
			
		}
	}

	

}

