package collections.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import collections.bean.Address;
import collections.bean.Employee;
import collections.dao.EmployeeDaoImpl;
import collections.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDaoImpl daoobj=new EmployeeDaoImpl();

	public void insertEmployee(Employee emp) {
		daoobj.insertEmployee(emp);
	}

	
	
	
		
		
		public boolean validateName(String Name) throws EmployeeException {

			boolean nameFlag = false;
			String nameRegEx =  "^[a-zA-Z]*$";

			if (!Pattern.matches(nameRegEx, Name)) {
				throw new EmployeeException("name should contain only alphabets");
			} else {
				nameFlag = true;
			}
			return nameFlag;
		}
		public boolean salaryCheck(double sal) throws EmployeeException {
	    	boolean salFlag = false;
	   
	    	if(sal>20000 && sal<500000) {
	    		salFlag=true;
	    	}else {
	    	throw new EmployeeException("salary should be greater than 20000 and less than 5 lakh");
	    	}
	    	return salFlag;
	    }
		public boolean dateCheck(String date) throws EmployeeException{
			boolean dateFlag=false;
			return dateFlag;
		}
		public boolean Idcheck(String employeeId) throws EmployeeException{
			boolean idFlag=false;
			String nameRegEx = "^[0-9]{5}_FS$";

			if (!Pattern.matches(nameRegEx, employeeId)) {
				throw new EmployeeException("id should be in the form of 12345_FS");
			} else {
				idFlag = true;
			}
			
			return idFlag;
		}
		public List<Employee>ByFirstName() {
			List<Employee> employee = new ArrayList<Employee>();
			employee = daoobj.getList();
			Comparator<Employee> name = new Comparator<Employee>() {
				public int compare(Employee o1, Employee o2) {
				if(o1.getFirstName().compareTo(o2.getFirstName())<0)
					return -1;
				if(o1.getFirstName().compareTo(o2.getFirstName())>0)
					return 1;
				else return 0;
				}
			};
			Collections.sort(employee, name);

			return employee;
		}
		public List<Employee>ByLastName() {
			List<Employee> employee1 = new ArrayList<Employee>();
			employee1 = daoobj.getList();
			Comparator<Employee> name1 = new Comparator<Employee>() {
				public int compare(Employee o1, Employee o2) {
				if(o1.getLastName().compareTo(o2.getLastName())<0)
					return -1;
				if(o1.getLastName().compareTo(o2.getLastName())>0)
					return 1;
				else return 0;
				}
			};
			Collections.sort(employee1, name1);

			return employee1;
		}

		public List<Employee> BySalary() {
			List<Employee> employee2 = new ArrayList<Employee>();
			employee2 = daoobj.getList();
			Comparator<Employee> salaries = new Comparator<Employee>() {

				@Override
				public int compare(Employee o1, Employee o2) {
					// TODO Auto-generated method stub
					if (o1.getSalary() < o2.getSalary()) 	return -1;
					if (o1.getSalary() < o2.getSalary()) return 1;
					else return 0;
				}
			};
			Collections.sort(employee2, salaries);

			return employee2;
		}
		public List<Employee> ByAddress() {
			String state2="";
			List<Employee> employee3 = new ArrayList<Employee>();
			employee3 = daoobj.getList();
			Comparator<Employee> address = new Comparator<Employee>() {
	Address address=new Address(state2);

				@Override
				public int compare(Employee o1, Employee o2) {
					// TODO Auto-generated method stub
					if(o1.getAddress().compareTo(o2.getAddress())<0) return -1;
					if (o1.getAddress().compareTo(o2.getAddress())>0) return 1;
					else return 0;
				}
			};
			Collections.sort(employee3, address);
			return employee3;
		}
	public List<Employee> ById(){
		List<Employee> employee7=new ArrayList<Employee>();
		employee7=daoobj.getList();
		Comparator<Employee> id = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
			if(o1.getEmployeeId().compareTo(o2.getEmployeeId())<0)
				return -1;
			if(o1.getEmployeeId().compareTo(o2.getEmployeeId())>0)
				return 1;
			else return 0;
			}
		};
		Collections.sort(employee7,id);
		return employee7;
	}



	public List<Employee> ByDepartment() {
		// TODO Auto-generated method stub
		return null;
	}

}
