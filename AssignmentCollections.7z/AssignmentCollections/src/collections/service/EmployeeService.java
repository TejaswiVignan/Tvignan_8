package collections.service;

import collections.bean.Employee;

public interface EmployeeService {
	public void insertEmployee(Employee emp);
}
