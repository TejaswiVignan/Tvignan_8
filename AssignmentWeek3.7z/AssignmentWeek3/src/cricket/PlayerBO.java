package cricket;

import java.util.Arrays;
import java.util.List;

public class PlayerBO {
	
		public static Player createPlayer(String data) {
			
			if(data.isBlank()) {
				return null;
			}
			Player player = new Player();
			
			List<String> playerInput = Arrays.asList(data.split(","));
			if(playerInput.size() > 0) {
					player.setName(playerInput.get(0));
					player.setCountry(playerInput.get(1));
					player.setSkill(playerInput.get(2));
			}
			
			return player;
			
		}


}
