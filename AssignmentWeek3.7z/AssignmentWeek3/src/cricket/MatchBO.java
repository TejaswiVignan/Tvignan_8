package cricket;

import java.util.Arrays;
import java.util.List;

public class MatchBO {
	
	public static Match createMatch(String data, List<Team> teamList)	{
	
		if(data.isBlank()) {
			return null;
		}
		
		Match match = new Match();
	
		List<String> matchInput = Arrays.asList(data.split(","));
		
		if(matchInput.size() > 0) {
				match.setDate(matchInput.get(0));
				
				String teamOne = matchInput.get(1);
				String teamTwo = matchInput.get(2);
				
				Team team1 = null, team2 = null;
				
				for(Team team : teamList) {
					if(team.getName().equals(teamOne)) {
						team1 = team;
					} else if(team.getName().equals(teamTwo)) {
						team2 = team;
					}
				}
				match.setTeamone(team1);
				match.setTeamtwo(team2);
				match.setVenue(matchInput.get(3));
			
		}
		return match;
	}
	
	public static String findTeam(String matchDate, List<Match> matchList) {
		String output = null;
		for(Match match : matchList) {
			if(match.getDate().equals(matchDate)) {
				output = match.getTeamone().getName()+ "," + match.getTeamtwo().getName();
			}
		}
		return output;
	}
	
	
	public static void findAllMatchesOfTeam(String teamName, List<Match> matchList) {
		String defaultOutput =  String.format("%15s %15s %15s %15s", "date","teamOne","teamTwo","venue"); 
		System.out.println(defaultOutput);
		for(Match match : matchList) {
			if(match.getTeamone().getName().equals(teamName) || match.getTeamtwo().getName().equals(teamName)) {
				System.out.println(match.toString());
			}
		}
	}
}
