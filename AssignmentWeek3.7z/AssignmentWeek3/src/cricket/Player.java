package cricket;
import java.util.*;


public class Player {
	private	String  name;
	private	String country;
	private	String skill;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getSkill() {
		return skill;
	}


	public void setSkill(String skill) {
		this.skill = skill;
	}


	public Player(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.skill = skill;
	}


	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public static void main(String[] args) {
		
		
		List<Player> playerList = new ArrayList<>();
		List<Team> teamList = new ArrayList<>();
		List<Match> matchList = new ArrayList<>();
		
		//player input read
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the player count");
		int playerCount = scan.nextInt();
		scan.nextLine();
		for(int i = 0 ; i < playerCount; i++) {
			System.out.printf("Enter player%d details\n", i+1);
			String player = scan.nextLine();
			playerList.add(PlayerBO.createPlayer(player));
		}
		
		//team
		scan.nextLine();
		System.out.println("Enter the team count");
		int teamCount = scan.nextInt();
		scan.nextLine();
		for(int i = 0 ; i < teamCount; i++) {
			System.out.printf("Enter team%d details\n", i+1);
			String team = scan.nextLine();
			teamList.add(TeamBO.createTeam(team, playerList));
		}
		
		//match
		scan.nextLine();
		System.out.println("Enter the match count");
		int matchCount = scan.nextInt();
		scan.nextLine();
		for(int i = 0 ; i < matchCount; i++) {
			System.out.printf("Enter match%d details\n", i+1);
			String match = scan.nextLine();
			matchList.add(MatchBO.createMatch(match, teamList));
		}
		

		String condition = "Yes";
		while(condition.equals("Yes")) {
			menu();
			int choice = scan.nextInt();
			if(choice == 1) {
				System.out.println("Enter match date");
				String date = scan.next();
				System.out.println(MatchBO.findTeam(date, matchList));
			}
			if(choice == 2) {
				System.out.println("Match details");
				System.out.println("Enter Team Name");
				String team = scan.next();
				MatchBO.findAllMatchesOfTeam(team, matchList);
			}
			System.out.println("Do you want to continue? Type Yes or No ");
			String checkIfContinue = scan.next();
			if(checkIfContinue.equals("Yes")) {
				continue;
			}else {
				condition = "No";
			}
		}
		
		
	}
	
	public static void menu() {
		System.out.println("Menu: \r\n" + 
				"1) Find Team \r\n" + 
				"2) Find All Matches in A Specific Venue \r\n" + 
				"Type 1 or 2 \r\n" + 
				"Enter your choice \r\n"
				);
		
	}
	

}

