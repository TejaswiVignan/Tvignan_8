package cricket;

public class Match {
	
	private	String  date;
	private	Team teamone;
	private	Team teamtwo;
	private	String venue;




	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Team getTeamone() {
		return teamone;
	}
	public void setTeamone(Team teamone) {
		this.teamone = teamone;
	}
	public Team getTeamtwo() {
		return teamtwo;
	}
	public void setTeamtwo(Team teamtwo) {
		this.teamtwo = teamtwo;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	
	public Match() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

@Override
	public String toString() {
	
		String output = String.format("%15s %15s %15s %s",date, teamone.getName(), teamtwo.getName(), venue);
		return output;
	}

}


