package cricket;

import java.util.Arrays;
import java.util.List;

public class TeamBO {
	
	public static Team createTeam(String data, List<Player> playerList) {
		
		if(data.isBlank()) {
			return null;
		}
		
		Team team = new Team();
		
		
		List<String> teamInput = Arrays.asList(data.split(","));
		if(teamInput.size() > 0) {
				team.setName(teamInput.get(0));
				String playerName = teamInput.get(1);
				if(!playerName.isBlank()) {
					for(Player player : playerList) {
						if(player.getName().equals(playerName)) {
							team.setPlayer(player);
							break;
						}
					}
				}	
		}
		return team;
	}

}
